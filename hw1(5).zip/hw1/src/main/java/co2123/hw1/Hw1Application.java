package co2123.hw1;

import co2123.hw1.domain.Menu;
import co2123.hw1.domain.Dish;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class Hw1Application implements CommandLineRunner {

    public static List<Menu> menus = new ArrayList<>();

    public static void main(String[] args) {
        SpringApplication.run(Hw1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {


        Dish d1 = new Dish();
        d1.setName("Wings");
        d1.setDescription("Wings glazed with your choice of sauce");
        d1.setDietary("Halal");
        d1.setPrice(9);

        Dish d2 = new Dish();
        d2.setName("Fries");
        d2.setDescription("Fries glazed with your choice of sauce");
        d2.setDietary("Vegan");
        d2.setPrice(3);

        List<Dish> dishes = new ArrayList<>();
        dishes.add(d1);
        dishes.add(d2);


        Menu m = new Menu();
        m.setId(1);
        m.setType("food");
        m.setRestaurant("Taste");
        m.setDishes(dishes);

        menus.add(m);
    }
}
