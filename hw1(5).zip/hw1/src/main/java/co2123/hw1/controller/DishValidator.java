package co2123.hw1.controller;

import co2123.hw1.Hw1Application;
import co2123.hw1.domain.Dish;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class DishValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return Dish.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Dish dish = (Dish) target;
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "Name of dish is required.");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "", "Description of dish is required.");

        if (dish.getDietary() != null && !dish.getDietary().isEmpty()) {
            if (!dish.getDietary().equals("Vegetarian") &&
                    !dish.getDietary().equals("Vegan") &&
                    !dish.getDietary().equals("Lactose Free")) {
                errors.rejectValue("dietary", "", "Dietary must be: 'Vegetarian', 'Vegan', or 'Lactose Free'");
            }
        } else {
            errors.rejectValue("dietary", "", "Dietary is required.");
        }

        if (dish.getPrice() < 15 || dish.getPrice() > 50) {
            errors.rejectValue("price", "", "Value needs to be between 15 and 50(inclusive).");
        }
    }
}
