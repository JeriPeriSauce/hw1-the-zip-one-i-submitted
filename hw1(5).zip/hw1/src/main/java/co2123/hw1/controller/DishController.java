package co2123.hw1.controller;

import co2123.hw1.Hw1Application;
import co2123.hw1.domain.Dish;
import co2123.hw1.domain.Dish;
import co2123.hw1.domain.Menu;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class DishController {

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.addValidators(new DishValidator());
    }

    @GetMapping("/dishes")
    public String showDishes(@RequestParam("menu") int menuId, Model model) {
        for (Menu menu : Hw1Application.menus) {
            if (menu.getId() == menuId) {
                model.addAttribute("dishes", menu.getDishes());
                model.addAttribute("menuId", menuId);
            }
        }
        return "dishes/list";
    }

    @GetMapping("/newDish")
    public String showDishForm(@RequestParam("menu") int menuId, Model model) {
        model.addAttribute("menuId", menuId);
        model.addAttribute("dish", new Dish());
        return "dishes/form";

    }

    @PostMapping("/addDish")
    public String addDish(@Valid @ModelAttribute Dish dish, BindingResult result, @RequestParam("menu") int menuId, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("menuId", menuId);
            model.addAttribute("dish", dish);
            return "dishes/form";
        }

        Dish newDish = new Dish();
        newDish.setName(dish.getName());
        newDish.setDescription(dish.getDescription());
        newDish.setDietary(dish.getDietary());
        newDish.setPrice(dish.getPrice());

        for (Menu menu : Hw1Application.menus) {
            if (menu.getId() == menuId) {
                List<Dish> menuDishes = menu.getDishes();
                if (menuDishes == null){
                    menuDishes = new ArrayList<>();
                }
                menuDishes.add(newDish);
                menu.setDishes(menuDishes);
            }
        }
        return "redirect:/menus";
    }
}
